# Problem Set 1

For this homework, I used Python 3 after gaining permission from Professor Brorson.

I used Jupyter notebooks, which I'm assuming the grader is familiar with, otherwise the docs are [here](https://jupyter-notebook.readthedocs.io/en/stable/).

Having pip installed is also necessary. To do that, go [here](https://pip.pypa.io/en/stable/installing/).

The extra Python dependencies I used include `matplotlib`, `numpy`, `scipy`, and `tqdm`.